import configparser
import os
from pyspark import SparkConf

def get_app_config(env):
    config = configparser.ConfigParser()
    
    # 1. Check Root (where --files puts it) or 2. Check configs/ (Local PC)
    if os.path.exists("application.conf"):
        config.read("application.conf")
    elif os.path.exists("configs/application.conf"):
        config.read("configs/application.conf")
    else:
        raise FileNotFoundError("application.conf not found in root or configs/ directory.")

    if not config.has_section(env):
        raise configparser.NoSectionError(env)

    app_conf = {}
    for (key, val) in config.items(env):
        app_conf[key] = val
    return app_conf

def get_pyspark_config(env):
    config = configparser.ConfigParser()
    
    # Repeat the same robust path check for pyspark.conf
    if os.path.exists("pyspark.conf"):
        config.read("pyspark.conf")
    elif os.path.exists("configs/pyspark.conf"):
        config.read("configs/pyspark.conf")
    else:
        raise FileNotFoundError("pyspark.conf not found in root or configs/ directory.")

    pyspark_conf = SparkConf()
    for (key, val) in config.items(env):
        pyspark_conf.set(key, val)
    return pyspark_conf